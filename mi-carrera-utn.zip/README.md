# Proyecto UTN - Ingeniería en Energía Eléctrica Tracker

Este proyecto es un tracker de materias para la carrera de Ingeniería en Energía Eléctrica (UTN), listo para desplegar en **GitHub Pages**.

## Contenido del repositorio
- React app con **tracker de materias**.
- TailwindCSS configurado para estilos.
- Funcionalidad de guardar progreso en localStorage.
- Exportar/Importar progreso en JSON.

## Instrucciones para subir a GitHub Pages

### 1️⃣ Crear el repo privado
Entra a tu cuenta de GitHub (`fikks5`) y crea un repositorio llamado:
```
mi-carrera-utn
```
- Tipo: **Privado**
- Inicializar sin README (ya viene en el zip)

### 2️⃣ Preparar tu proyecto local
Descomprimí el `.zip` en tu PC.
Abre terminal dentro de la carpeta del proyecto.

### 3️⃣ Inicializar Git y conectar tu repo
```bash
git init
git remote add origin https://github.com/fikks5/mi-carrera-utn.git
```

### 4️⃣ Instalar dependencias y gh-pages
```bash
npm install
npm install --save-dev gh-pages
```

### 5️⃣ Configurar package.json para GitHub Pages
Dentro de `package.json`, agregar:
```json
"homepage": "https://fikks5.github.io/mi-carrera-utn/"
```
Agregar scripts:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d build"
```

### 6️⃣ Hacer commit y deploy
```bash
git add .
git commit -m "Primer commit - Tracker UTN"
npm run deploy
```

### 7️⃣ Listo
- La aplicación debería estar disponible en:
```
https://fikks5.github.io/mi-carrera-utn/
```
- Cada vez que hagas cambios: `npm run deploy`

## Funcionalidades del tracker
- Marcar materias como **Pendiente / Cursando / Aprobada**
- Filtrar materias por **Año**
- Ver **porcentaje completado** y materias aprobadas
- Guardar automáticamente en **localStorage**
- **Exportar/Importar** progreso en JSON
